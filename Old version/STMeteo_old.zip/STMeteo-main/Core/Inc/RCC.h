/*
 * RCC.h
 *
 *  Created on: Dec 18, 2024
 *      Author: FlY DeN
 */

#ifndef INC_RCC_H_
#define INC_RCC_H_

#include "main.h"

void CMSIS_Clock_Config(void);

#endif /* INC_RCC_H_ */
